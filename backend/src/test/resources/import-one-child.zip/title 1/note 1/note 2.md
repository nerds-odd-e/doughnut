---
note_id: 6
created_at: 2025-01-10 14:18:21.0
updated_at: 2025-01-10 14:18:50.0
---
# note 2
content of note 2